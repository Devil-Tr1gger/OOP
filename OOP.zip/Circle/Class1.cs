﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        Circle circle = new Circle(5);
        circle.GetArea();

        circle.Radius = -2;

        Circle circle2 = new Circle(1);
        circle2.GetArea();
    }
}
