﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Circle
{
    private double radius;

    public double Radius
    {
        get { return radius; }
        set
        {
            if (value <= 0)
            {
                Console.WriteLine("Радиус должен быть больше 0!");
            }
            else
            {
                radius = value;
            }
        }
    }

    public Circle(double radius)
    {
        Radius = radius;
    }

    public void GetArea()
    {
        double area = Math.PI * radius * radius;
        Console.WriteLine($"Площадь круга: {area}.");
    }
}