﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        Pet pet = new Pet("Рекс", 80);
        pet.Play();
        pet.Rest();

        pet.Energy = 150;

        pet.Play();
    }
}