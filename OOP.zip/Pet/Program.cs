﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Pet
{
    private string name;
    private int energy;

    public string Name
    {
        get { return name; }
        set { name = value; }
    }

    public int Energy
    {
        get { return energy; }
        set
        {
            if (value < 0 || value > 100)
            {
                Console.WriteLine("Энергия должна быть от 0 до 100!");
            }
            else
            {
                energy = value;
            }
        }
    }

    public Pet(string name, int energy)
    {
        Name = name;
        Energy = energy;
    }

    public void Play()
    {
        energy = Math.Max(energy - 20, 0);
        Console.WriteLine($"{Name} играет, энергия: {energy}.");
    }

    public void Rest()
    {
        energy = Math.Min(energy + 30, 100);
        Console.WriteLine($"{Name} отдыхает, энергия: {energy}.");
    }
}
