﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Phone
{
    private string brand;
    private int batteryLevel;

    public string Brand
    {
        get { return brand; }
        set { brand = value; }
    }

    public int BatteryLevel
    {
        get { return batteryLevel; }
        set
        {
            if (value < 0 || value > 100)
            {
                Console.WriteLine("Заряд должен быть от 0 до 100!");
            }
            else
            {
                batteryLevel = value;
            }
        }
    }

    public Phone(string brand, int batteryLevel)
    {
        Brand = brand;
        BatteryLevel = batteryLevel;
    }

    public void UsePhone()
    {
        batteryLevel = Math.Max(batteryLevel - 10, 0);
        Console.WriteLine($"Телефон {Brand}, заряд: {batteryLevel}%.");
    }
}