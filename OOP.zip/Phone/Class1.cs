﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        Phone phone = new Phone("Samsung", 90);
        phone.UsePhone();
        phone.UsePhone();

        phone.BatteryLevel = -10;
    }
}
