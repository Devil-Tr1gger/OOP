﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        BankAccount account = new BankAccount("Иван", 1000);

        account.Deposit(500);
        account.Withdraw(500);
        account.Withdraw(1500);
    }
}