﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class BankAccount
{
    private string owner;
    private double balance;

    public string Owner
    {
        get { return owner; }
        set { owner = value; }
    }

    public double Balance
    {
        get { return balance; }
        set
        {
            if (value < 0)
            {
                Console.WriteLine("Баланс не может быть отрицательным!");
            }
            else
            {
                balance = value;
            }
        }
    }

    public BankAccount(string owner, double balance)
    {
        Owner = owner;
        Balance = balance;
    }

    public void Deposit(double amount)
    {
        if (amount > 0)
        {
            balance += amount;
            Console.WriteLine($"{Owner}, баланс: {balance}.");
        }
        else
        {
            Console.WriteLine("Сумма депозита должна быть положительной!");
        }
    }

    public void Withdraw(double amount)
    {
        if (amount > 0)
        {
            if (amount <= balance)
            {
                balance -= amount;
                Console.WriteLine($"{Owner}, баланс: {balance}.");
            }
            else
            {
                Console.WriteLine("Недостаточно средств!");
            }
        }
        else
        {
            Console.WriteLine("Сумма снятия должна быть положительной!");
        }
    }
}