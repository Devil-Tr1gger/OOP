﻿using System;

class Program
{
    static void Main()
    {
        Person person1 = new Person("Маша", 25);
        person1.SayHello();

        Person person2 = new Person("Маша", 150);
        person2.SayHello();

        Person person3 = new Person("Маша", -5);
        person3.SayHello();
    }
}
